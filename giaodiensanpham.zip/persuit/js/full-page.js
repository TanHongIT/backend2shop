;(function($) {
    "use strict";

    $('#fullpage').fullpage({
        sectionsColor: ['#fff', '#fff', '#fff', '#fff', '#fff'],
        'navigation': true,
    });
    
    
})(jQuery)